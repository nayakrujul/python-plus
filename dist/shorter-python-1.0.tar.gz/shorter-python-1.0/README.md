# python-plus
Shorten your Python code with shorter syntax.
